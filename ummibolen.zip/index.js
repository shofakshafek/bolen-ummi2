
const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
const P = require('pino');
const fs = require('fs');

const cfg = JSON.parse(fs.readFileSync('./config.json'));
const dbFile = './database.json';

function initDB(){
 if(!fs.existsSync(dbFile)){
   fs.writeFileSync(dbFile, JSON.stringify({
     menu:[
       {nama:'Bolen Pisang',harga:12000,stok:20},
       {nama:'Bolen Coklat',harga:15000,stok:15}
     ],
     orders:[]
   },null,2));
 }
}
function db(){ return JSON.parse(fs.readFileSync(dbFile));}
function save(data){ fs.writeFileSync(dbFile, JSON.stringify(data,null,2));}

async function start(){
 initDB();
 const { state, saveCreds } = await useMultiFileAuthState('./session');
 const { version } = await fetchLatestBaileysVersion();
 const sock = makeWASocket({version, auth:state, logger:P({level:'silent'})});

 if(!sock.authState.creds.registered){
   const code = await sock.requestPairingCode(cfg.owner_number);
   console.log('Pairing Code:', code);
 }

 sock.ev.on('creds.update', saveCreds);
 sock.ev.on('connection.update', ({connection,lastDisconnect})=>{
   if(connection==='close'){
    const retry = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
    if(retry) start();
   }
   if(connection==='open') console.log('Bot Connected');
 });

 sock.ev.on('messages.upsert', async ({messages,type})=>{
   if(type!=='notify') return;
   const m = messages[0];
   if(!m.message || m.key.fromMe) return;
   const jid = m.key.remoteJid;
   const text = (m.message.conversation || m.message.extendedTextMessage?.text || '').trim();
   const cmd = text.toLowerCase();
   const reply = (t)=>sock.sendMessage(jid,{text:t},{quoted:m});
   let data = db();

   if(cmd==='.ping') return reply('Pong');
   if(cmd==='.menu'){
     let out='*Menu '+cfg.shop_name+'*\n';
     data.menu.forEach((x,i)=> out += `${i+1}. ${x.nama} - Rp${x.harga}\n`);
     return reply(out);
   }
   if(cmd==='.stok'){
     let out='*Stok Ready*\n';
     data.menu.forEach((x,i)=> out += `${i+1}. ${x.nama}: ${x.stok}\n`);
     return reply(out);
   }
   if(cmd==='.alamat'){
     await sock.sendMessage(jid,{location:{
      degreesLatitude:cfg.location.lat,
      degreesLongitude:cfg.location.lng,
      name:cfg.shop_name,
      address:cfg.address
     }},{quoted:m});
     return;
   }
   if(cmd==='.order') return reply('Format:\n.order nama|produk|jumlah|catatan');

   if(cmd.startswith?.('.order ')){}
   if(cmd.startsWith('.order ')){
     const p = text.slice(7).split('|');
     if(p.length<4) return reply('Format salah');
     const [nama,produk,jmlTxt,catatan]=p;
     const item = data.menu.find(v=>v.nama.toLowerCase()===produk.toLowerCase());
     if(!item) return reply('Produk tidak ada');
     const jml = parseInt(jmlTxt);
     if(isNaN(jml)||jml<1) return reply('Jumlah salah');
     if(item.stok<jml) return reply('Stok kurang');
     item.stok -= jml;
     data.orders.push({nama,produk:item.nama,jumlah:jml,catatan,waktu:new Date().toISOString()});
     save(data);
     return reply(`Pesanan diterima\nNama: ${nama}\nProduk: ${item.nama}\nJumlah: ${jml}\nTotal: Rp${item.harga*jml}`);
   }
 });
}
start();
