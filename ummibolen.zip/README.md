# Bolen Ummi Bot

Install:
npm install

Run:
npm start

Edit config.json lalu ganti owner_number dengan nomor WhatsApp.
